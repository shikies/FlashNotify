package com.flashnotify;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.flashnotify.notificationlistener.FlashNotifyListenerService;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private Switch switchMain;
    private TextView tvStatus;
    private TextView tvPermCamera;
    private TextView tvPermNotification;
    private Button btnGrantCamera;
    private Button btnGrantNotification;
    private Button btnTestFlash;
    private Button btnSelectApps;
    private TextView tvSelectedApps;
    private TextView tvFlashCount;
    private TextView tvFlashSpeed;
    private ImageButton btnFlashCountMinus;
    private ImageButton btnFlashCountPlus;
    private Button btnFlashCountInfinite;
    private Button btnSpeedFast;
    private Button btnSpeedMedium;
    private Button btnSpeedSlow;
    private Button btnSpeedVeryFast;
    private Switch switchStopOnDismiss;

    private SharedPreferences prefs;
    private int flashCount = 5;
    private int flashInterval = 300;
    private boolean infiniteFlash = false;
    private boolean stopOnDismiss = true;

    // Receiver to stop flash when a notification is removed
    private BroadcastReceiver notificationRemovedReceiver;

    private static final int REQUEST_CAMERA = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(FlashNotifyListenerService.PREFS_NAME, MODE_PRIVATE);
        flashCount    = prefs.getInt(FlashNotifyListenerService.KEY_FLASH_COUNT, 5);
        flashInterval = prefs.getInt(FlashNotifyListenerService.KEY_FLASH_INTERVAL, 300);
        infiniteFlash = prefs.getBoolean(FlashNotifyListenerService.KEY_INFINITE_FLASH, false);
        stopOnDismiss = prefs.getBoolean(FlashNotifyListenerService.KEY_STOP_ON_DISMISS, true);

        initViews();
        setupListeners();
        updateUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
        updateUI();

        // Register receiver for notification removed events
        notificationRemovedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (stopOnDismiss) {
                    FlashNotifyListenerService.stopFlashExternal(MainActivity.this);
                }
            }
        };
        IntentFilter filter = new IntentFilter(FlashNotifyListenerService.ACTION_NOTIFICATION_REMOVED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(notificationRemovedReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(notificationRemovedReceiver, filter);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (notificationRemovedReceiver != null) {
            try {
                unregisterReceiver(notificationRemovedReceiver);
            } catch (Exception ignored) {}
            notificationRemovedReceiver = null;
        }
    }

    private void initViews() {
        switchMain              = findViewById(R.id.switch_main);
        tvStatus                = findViewById(R.id.tv_status);
        tvPermCamera            = findViewById(R.id.tv_perm_camera);
        tvPermNotification      = findViewById(R.id.tv_perm_notification);
        btnGrantCamera          = findViewById(R.id.btn_grant_camera);
        btnGrantNotification    = findViewById(R.id.btn_grant_notification);
        btnTestFlash            = findViewById(R.id.btn_test_flash);
        btnSelectApps           = findViewById(R.id.btn_select_apps);
        tvSelectedApps          = findViewById(R.id.tv_selected_apps);
        tvFlashCount            = findViewById(R.id.tv_flash_count);
        tvFlashSpeed            = findViewById(R.id.tv_flash_speed);
        btnFlashCountMinus      = findViewById(R.id.btn_flash_count_minus);
        btnFlashCountPlus       = findViewById(R.id.btn_flash_count_plus);
        btnFlashCountInfinite   = findViewById(R.id.btn_flash_count_infinite);
        btnSpeedVeryFast        = findViewById(R.id.btn_speed_very_fast);
        btnSpeedFast            = findViewById(R.id.btn_speed_fast);
        btnSpeedMedium          = findViewById(R.id.btn_speed_medium);
        btnSpeedSlow            = findViewById(R.id.btn_speed_slow);
        switchStopOnDismiss     = findViewById(R.id.switch_stop_on_dismiss);
    }

    private void setupListeners() {
        switchMain.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isNotificationListenerEnabled()) {
                switchMain.setChecked(false);
                Toast.makeText(this, "请先授予通知访问权限", Toast.LENGTH_SHORT).show();
                openNotificationListenerSettings();
                return;
            }
            prefs.edit().putBoolean(FlashNotifyListenerService.KEY_ENABLED, isChecked).apply();
            updateStatusDisplay();
        });

        btnGrantCamera.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA);
            }
        });

        btnGrantNotification.setOnClickListener(v -> openNotificationListenerSettings());

        btnTestFlash.setOnClickListener(v -> {
            int count = infiniteFlash ? -1 : flashCount;
            FlashNotifyListenerService.triggerFlashExternal(this, count, flashInterval);
            String msg = infiniteFlash ? "测试闪光灯：无限次（点击停止）" : "测试闪光灯：" + flashCount + "次";
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });

        btnSelectApps.setOnClickListener(v -> {
            startActivity(new Intent(this, AppSelectorActivity.class));
        });

        btnFlashCountMinus.setOnClickListener(v -> {
            if (!infiniteFlash && flashCount > 1) {
                flashCount--;
                saveFlashSettings();
                updateFlashCountDisplay();
            }
        });

        btnFlashCountPlus.setOnClickListener(v -> {
            if (!infiniteFlash) {
                flashCount++;
                saveFlashSettings();
                updateFlashCountDisplay();
            }
        });

        btnFlashCountInfinite.setOnClickListener(v -> {
            infiniteFlash = !infiniteFlash;
            saveFlashSettings();
            updateFlashCountDisplay();
        });

        switchStopOnDismiss.setOnCheckedChangeListener((buttonView, isChecked) -> {
            stopOnDismiss = isChecked;
            prefs.edit().putBoolean(FlashNotifyListenerService.KEY_STOP_ON_DISMISS, stopOnDismiss).apply();
        });

        View.OnClickListener speedListener = v -> {
            if (v.getId() == R.id.btn_speed_very_fast) flashInterval = 100;
            else if (v.getId() == R.id.btn_speed_fast) flashInterval = 200;
            else if (v.getId() == R.id.btn_speed_medium) flashInterval = 350;
            else if (v.getId() == R.id.btn_speed_slow) flashInterval = 600;
            saveFlashSettings();
            updateSpeedDisplay();
        };

        btnSpeedVeryFast.setOnClickListener(speedListener);
        btnSpeedFast.setOnClickListener(speedListener);
        btnSpeedMedium.setOnClickListener(speedListener);
        btnSpeedSlow.setOnClickListener(speedListener);
    }

    private void updateUI() {
        boolean enabled = prefs.getBoolean(FlashNotifyListenerService.KEY_ENABLED, false);
        switchMain.setChecked(enabled);
        switchStopOnDismiss.setChecked(stopOnDismiss);
        updateStatusDisplay();
        updatePermissionStatus();
        updateFlashCountDisplay();
        updateSpeedDisplay();
        updateSelectedAppsDisplay();
    }

    private void updateStatusDisplay() {
        boolean enabled = prefs.getBoolean(FlashNotifyListenerService.KEY_ENABLED, false);
        boolean notifEnabled = isNotificationListenerEnabled();
        if (enabled && notifEnabled) {
            tvStatus.setText("监听中 ●");
            tvStatus.setTextColor(getColor(R.color.green));
        } else {
            tvStatus.setText("已停止 ○");
            tvStatus.setTextColor(getColor(R.color.gray));
        }
    }

    private void updatePermissionStatus() {
        boolean hasCamera = checkSelfPermission(android.Manifest.permission.CAMERA)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
        boolean hasNotif = isNotificationListenerEnabled();

        if (hasCamera) {
            tvPermCamera.setText("✓ 已授权");
            tvPermCamera.setTextColor(getColor(R.color.green));
            btnGrantCamera.setVisibility(View.GONE);
        } else {
            tvPermCamera.setText("未授权");
            tvPermCamera.setTextColor(getColor(R.color.orange));
            btnGrantCamera.setVisibility(View.VISIBLE);
        }

        if (hasNotif) {
            tvPermNotification.setText("✓ 已授权");
            tvPermNotification.setTextColor(getColor(R.color.green));
            btnGrantNotification.setVisibility(View.GONE);
        } else {
            tvPermNotification.setText("未授权");
            tvPermNotification.setTextColor(getColor(R.color.orange));
            btnGrantNotification.setVisibility(View.VISIBLE);
        }
    }

    private void updateFlashCountDisplay() {
        if (infiniteFlash) {
            tvFlashCount.setText("∞");
            btnFlashCountMinus.setAlpha(0.35f);
            btnFlashCountPlus.setAlpha(0.35f);
            btnFlashCountInfinite.setBackgroundColor(getColor(R.color.primary));
        } else {
            tvFlashCount.setText(String.valueOf(flashCount));
            btnFlashCountMinus.setAlpha(1.0f);
            btnFlashCountPlus.setAlpha(1.0f);
            btnFlashCountInfinite.setBackgroundColor(getColor(R.color.surface));
        }
    }

    private void updateSpeedDisplay() {
        String speedText;
        if (flashInterval <= 150) {
            btnSpeedVeryFast.setBackgroundColor(getColor(R.color.primary));
            btnSpeedFast.setBackgroundColor(getColor(R.color.surface));
            btnSpeedMedium.setBackgroundColor(getColor(R.color.surface));
            btnSpeedSlow.setBackgroundColor(getColor(R.color.surface));
            speedText = "极快";
        } else if (flashInterval <= 250) {
            btnSpeedVeryFast.setBackgroundColor(getColor(R.color.surface));
            btnSpeedFast.setBackgroundColor(getColor(R.color.primary));
            btnSpeedMedium.setBackgroundColor(getColor(R.color.surface));
            btnSpeedSlow.setBackgroundColor(getColor(R.color.surface));
            speedText = "快速";
        } else if (flashInterval <= 450) {
            btnSpeedVeryFast.setBackgroundColor(getColor(R.color.surface));
            btnSpeedFast.setBackgroundColor(getColor(R.color.surface));
            btnSpeedMedium.setBackgroundColor(getColor(R.color.primary));
            btnSpeedSlow.setBackgroundColor(getColor(R.color.surface));
            speedText = "中速";
        } else {
            btnSpeedVeryFast.setBackgroundColor(getColor(R.color.surface));
            btnSpeedFast.setBackgroundColor(getColor(R.color.surface));
            btnSpeedMedium.setBackgroundColor(getColor(R.color.surface));
            btnSpeedSlow.setBackgroundColor(getColor(R.color.primary));
            speedText = "慢速";
        }
        tvFlashSpeed.setText(speedText);
    }

    private void updateSelectedAppsDisplay() {
        Set<String> packages = prefs.getStringSet(
                FlashNotifyListenerService.KEY_MONITORED_PACKAGES, new HashSet<>());
        if (packages.isEmpty()) {
            tvSelectedApps.setText("监听所有应用通知");
        } else {
            tvSelectedApps.setText("已选择 " + packages.size() + " 个应用");
        }
    }

    private void saveFlashSettings() {
        prefs.edit()
            .putInt(FlashNotifyListenerService.KEY_FLASH_COUNT, flashCount)
            .putInt(FlashNotifyListenerService.KEY_FLASH_INTERVAL, flashInterval)
            .putBoolean(FlashNotifyListenerService.KEY_INFINITE_FLASH, infiniteFlash)
            .apply();
    }

    private boolean isNotificationListenerEnabled() {
        String flat = Settings.Secure.getString(
                getContentResolver(), "enabled_notification_listeners");
        if (flat == null) return false;
        String[] names = flat.split(":");
        for (String name : names) {
            ComponentName cn = ComponentName.unflattenFromString(name);
            if (cn != null && getPackageName().equals(cn.getPackageName())) return true;
        }
        return false;
    }

    private void openNotificationListenerSettings() {
        startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA) {
            updatePermissionStatus();
        }
    }
}
