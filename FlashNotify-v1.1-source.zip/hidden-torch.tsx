import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

interface HiddenTorchProps {
  enabled: boolean;
}

/**
 * A hidden CameraView component that controls the device torch/flashlight.
 * This component is invisible (0x0 size) but keeps the camera active
 * so we can toggle the torch via the enableTorch prop.
 */
export function HiddenTorch({ enabled }: HiddenTorchProps) {
  const [permission, requestPermission] = useCameraPermissions();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!permission?.granted && Platform.OS === 'android') {
      requestPermission();
    }
  }, []);

  useEffect(() => {
    if (permission?.granted) {
      setReady(true);
    }
  }, [permission]);

  if (!ready || Platform.OS !== 'android') {
    return null;
  }

  return (
    <View style={styles.container} pointerEvents="none">
      <CameraView
        style={styles.camera}
        facing="back"
        enableTorch={enabled}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    width: 1,
    height: 1,
    opacity: 0,
    overflow: 'hidden',
  },
  camera: {
    width: 1,
    height: 1,
  },
});
