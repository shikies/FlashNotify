import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  Switch,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useInstalledApps } from '@/hooks/use-installed-apps';
import { useSettings } from '@/hooks/use-settings';
import { useColors } from '@/hooks/use-colors';
import { IconSymbol } from '@/components/ui/icon-symbol';

export default function AppSelectorScreen() {
  const router = useRouter();
  const colors = useColors();
  const { apps, loading } = useInstalledApps();
  const { settings, toggleMonitoredPackage, setMonitoredPackages } = useSettings();
  const [search, setSearch] = useState('');

  const filteredApps = useMemo(() => {
    if (!search.trim()) return apps;
    const q = search.toLowerCase();
    return apps.filter(
      (a) =>
        a.appName.toLowerCase().includes(q) ||
        a.packageName.toLowerCase().includes(q)
    );
  }, [apps, search]);

  const isSelected = (pkg: string) =>
    settings.monitoredPackages.includes(pkg);

  const handleSelectAll = () => {
    setMonitoredPackages(apps.map((a) => a.packageName));
  };

  const handleClearAll = () => {
    setMonitoredPackages([]);
  };

  return (
    <ScreenContainer edges={['top', 'left', 'right']} containerClassName="bg-background">
      <StatusBar barStyle="light-content" backgroundColor="#0F172A" />

      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={styles.backBtn}
          onPress={() => router.back()}
        >
          <IconSymbol name="chevron.left.forwardslash.chevron.right" size={20} color={colors.primary} />
          <Text style={[styles.backText, { color: colors.primary }]}>返回</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>选择监听的应用</Text>
        <View style={styles.headerRight} />
      </View>

      {/* Search */}
      <View style={[styles.searchContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={{ color: colors.muted, marginRight: 8 }}>🔍</Text>
        <TextInput
          style={[styles.searchInput, { color: colors.foreground }]}
          placeholder="搜索应用名称或包名..."
          placeholderTextColor={colors.muted}
          value={search}
          onChangeText={setSearch}
          returnKeyType="done"
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Text style={{ color: colors.muted }}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Stats & Actions */}
      <View style={[styles.statsRow, { borderBottomColor: colors.border }]}>
        <Text style={[styles.statsText, { color: colors.muted }]}>
          已选 {settings.monitoredPackages.length} 个应用
          {settings.monitoredPackages.length === 0 && '（监听全部）'}
        </Text>
        <View style={styles.actionBtns}>
          <TouchableOpacity onPress={handleSelectAll} style={styles.actionBtn}>
            <Text style={[styles.actionBtnText, { color: colors.primary }]}>全选</Text>
          </TouchableOpacity>
          <Text style={{ color: colors.border, marginHorizontal: 4 }}>|</Text>
          <TouchableOpacity onPress={handleClearAll} style={styles.actionBtn}>
            <Text style={[styles.actionBtnText, { color: colors.muted }]}>清空</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* App List */}
      <FlatList
        data={filteredApps}
        keyExtractor={(item) => item.packageName}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <View style={[styles.appItem, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.appIcon}>
              <Text style={styles.appIconText}>
                {item.appName.charAt(0)}
              </Text>
            </View>
            <View style={styles.appInfo}>
              <Text style={[styles.appName, { color: colors.foreground }]} numberOfLines={1}>
                {item.appName}
              </Text>
              <Text style={[styles.packageName, { color: colors.muted }]} numberOfLines={1}>
                {item.packageName}
              </Text>
            </View>
            <Switch
              value={isSelected(item.packageName)}
              onValueChange={() => toggleMonitoredPackage(item.packageName)}
              trackColor={{ false: colors.border, true: colors.primary + '80' }}
              thumbColor={isSelected(item.packageName) ? colors.primary : colors.muted}
            />
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyText, { color: colors.muted }]}>
              {loading ? '加载中...' : '未找到匹配的应用'}
            </Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 60,
  },
  backText: {
    fontSize: 16,
    marginLeft: 4,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 17,
    fontWeight: '600',
  },
  headerRight: {
    minWidth: 60,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 16,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    padding: 0,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 0.5,
  },
  statsText: {
    fontSize: 13,
  },
  actionBtns: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionBtn: {
    paddingHorizontal: 4,
    paddingVertical: 2,
  },
  actionBtnText: {
    fontSize: 14,
    fontWeight: '500',
  },
  listContent: {
    padding: 16,
    gap: 8,
  },
  appItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 8,
  },
  appIcon: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: '#3B82F620',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  appIconText: {
    fontSize: 20,
    fontWeight: '700',
    color: '#3B82F6',
  },
  appInfo: {
    flex: 1,
    marginRight: 8,
  },
  appName: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 2,
  },
  packageName: {
    fontSize: 12,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 15,
  },
});
