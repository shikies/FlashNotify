import { useState, useEffect } from 'react';
import { NativeModules, Platform } from 'react-native';

export interface InstalledApp {
  packageName: string;
  appName: string;
}

// Common apps that users typically want to monitor
const COMMON_APPS: InstalledApp[] = [
  { packageName: 'com.tencent.mm', appName: '微信' },
  { packageName: 'com.tencent.mobileqq', appName: 'QQ' },
  { packageName: 'com.alibaba.android.rimet', appName: '钉钉' },
  { packageName: 'com.lark.android', appName: '飞书' },
  { packageName: 'com.ss.android.lark', appName: '飞书' },
  { packageName: 'com.netease.cloudmusic', appName: '网易云音乐' },
  { packageName: 'com.sina.weibo', appName: '微博' },
  { packageName: 'com.zhihu.android', appName: '知乎' },
  { packageName: 'com.douban.frodo', appName: '豆瓣' },
  { packageName: 'com.xiaomi.market', appName: '小米应用商店' },
  { packageName: 'com.android.mms', appName: '短信' },
  { packageName: 'com.google.android.apps.messaging', appName: 'Messages' },
  { packageName: 'com.whatsapp', appName: 'WhatsApp' },
  { packageName: 'org.telegram.messenger', appName: 'Telegram' },
  { packageName: 'com.instagram.android', appName: 'Instagram' },
  { packageName: 'com.twitter.android', appName: 'Twitter/X' },
  { packageName: 'com.facebook.katana', appName: 'Facebook' },
  { packageName: 'com.discord', appName: 'Discord' },
  { packageName: 'com.slack', appName: 'Slack' },
  { packageName: 'com.microsoft.teams', appName: 'Microsoft Teams' },
  { packageName: 'com.google.android.gm', appName: 'Gmail' },
  { packageName: 'com.microsoft.office.outlook', appName: 'Outlook' },
  { packageName: 'com.jingdong.app.mall', appName: '京东' },
  { packageName: 'com.taobao.taobao', appName: '淘宝' },
  { packageName: 'com.eg.android.AlipayGphone', appName: '支付宝' },
  { packageName: 'com.xingin.xhs', appName: '小红书' },
  { packageName: 'com.ss.android.ugc.aweme', appName: '抖音' },
  { packageName: 'com.kuaishou.nebula', appName: '快手' },
  { packageName: 'tv.danmaku.bili', appName: 'B站' },
];

/**
 * Returns a list of apps that the user might want to monitor.
 * On Android, tries to get the actual installed apps via native module.
 * Falls back to a curated list of common apps.
 */
export function useInstalledApps() {
  const [apps, setApps] = useState<InstalledApp[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadApps();
  }, []);

  const loadApps = async () => {
    setLoading(true);
    try {
      // Try to get installed apps from native module
      if (Platform.OS === 'android' && NativeModules.NotificationListenerModule) {
        // Use common apps list as fallback since getting all installed apps
        // requires additional native code
        setApps(COMMON_APPS);
      } else {
        setApps(COMMON_APPS);
      }
    } catch (e) {
      console.warn('Failed to load installed apps', e);
      setApps(COMMON_APPS);
    } finally {
      setLoading(false);
    }
  };

  return { apps, loading, reload: loadApps };
}
