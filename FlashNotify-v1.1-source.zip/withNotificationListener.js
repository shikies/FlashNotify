const { withAndroidManifest, withDangerousMod } = require('@expo/config-plugins');
const path = require('path');
const fs = require('fs');

/**
 * Expo Config Plugin to add NotificationListenerService to AndroidManifest.xml
 * and copy Java source files to the Android project.
 */
const withNotificationListener = (config) => {
  // Step 1: Add service declaration to AndroidManifest.xml
  config = withAndroidManifest(config, (config) => {
    const manifest = config.modResults;
    const application = manifest.manifest.application[0];

    if (!application.service) {
      application.service = [];
    }

    // Check if service already added
    const serviceExists = application.service.some(
      (s) => s.$?.['android:name']?.includes('FlashNotifyListenerService')
    );

    if (!serviceExists) {
      application.service.push({
        $: {
          'android:name': 'com.flashnotify.notificationlistener.FlashNotifyListenerService',
          'android:label': 'FlashNotify Notification Listener',
          'android:exported': 'false',
          'android:permission': 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
        },
        'intent-filter': [
          {
            action: [
              {
                $: {
                  'android:name': 'android.service.notification.NotificationListenerService',
                },
              },
            ],
          },
        ],
      });
    }

    return config;
  });

  // Step 2: Copy Java source files to Android project
  config = withDangerousMod(config, [
    'android',
    async (config) => {
      const projectRoot = config.modRequest.projectRoot;
      const androidRoot = path.join(projectRoot, 'android');
      const packageDir = path.join(
        androidRoot,
        'app/src/main/java/com/flashnotify/notificationlistener'
      );

      // Create directory if it doesn't exist
      if (!fs.existsSync(packageDir)) {
        fs.mkdirSync(packageDir, { recursive: true });
      }

      // Source directory
      const sourceDir = path.join(
        projectRoot,
        'modules/notification-listener/android/src/main/java/com/flashnotify/notificationlistener'
      );

      // Copy all Java files
      if (fs.existsSync(sourceDir)) {
        const files = fs.readdirSync(sourceDir);
        for (const file of files) {
          if (file.endsWith('.java')) {
            const src = path.join(sourceDir, file);
            const dest = path.join(packageDir, file);
            fs.copyFileSync(src, dest);
            console.log(`Copied ${file} to Android project`);
          }
        }
      }

      // Register the package in MainApplication
      const mainAppPath = path.join(androidRoot, 'app/src/main/java/com/flashnotify/MainApplication.kt');
      const mainAppPathJava = path.join(androidRoot, 'app/src/main/java/com/flashnotify/MainApplication.java');

      // Try to find MainApplication
      let mainAppFile = null;
      if (fs.existsSync(mainAppPath)) {
        mainAppFile = mainAppPath;
      } else if (fs.existsSync(mainAppPathJava)) {
        mainAppFile = mainAppPathJava;
      } else {
        // Search for MainApplication
        const searchDirs = [
          path.join(androidRoot, 'app/src/main/java'),
        ];
        for (const dir of searchDirs) {
          if (fs.existsSync(dir)) {
            const found = findFile(dir, 'MainApplication.kt') || findFile(dir, 'MainApplication.java');
            if (found) {
              mainAppFile = found;
              break;
            }
          }
        }
      }

      if (mainAppFile) {
        let content = fs.readFileSync(mainAppFile, 'utf8');
        const importLine = 'import com.flashnotify.notificationlistener.NotificationListenerPackage';
        const packageLine = 'NotificationListenerPackage()';

        if (!content.includes('NotificationListenerPackage')) {
          if (mainAppFile.endsWith('.kt')) {
            // Kotlin
            content = content.replace(
              /import com\.facebook\.react\.ReactApplication/,
              `import com.facebook.react.ReactApplication\n${importLine}`
            );
            content = content.replace(
              /PackageList\(this\)\.packages/,
              `PackageList(this).packages.also { it.add(${packageLine}) }`
            );
          } else {
            // Java
            content = content.replace(
              /import com\.facebook\.react\.ReactApplication;/,
              `import com.facebook.react.ReactApplication;\n${importLine};`
            );
            content = content.replace(
              /new PackageList\(this\)\.getPackages\(\)/,
              `new PackageList(this).getPackages(); packages.add(new ${packageLine});`
            );
          }
          fs.writeFileSync(mainAppFile, content);
          console.log('Registered NotificationListenerPackage in MainApplication');
        }
      }

      return config;
    },
  ]);

  return config;
};

function findFile(dir, filename) {
  const files = fs.readdirSync(dir, { withFileTypes: true });
  for (const file of files) {
    const fullPath = path.join(dir, file.name);
    if (file.isDirectory()) {
      const found = findFile(fullPath, filename);
      if (found) return found;
    } else if (file.name === filename) {
      return fullPath;
    }
  }
  return null;
}

module.exports = withNotificationListener;
